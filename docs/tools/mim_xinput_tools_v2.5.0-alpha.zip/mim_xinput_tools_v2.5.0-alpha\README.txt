﻿MIM XInput Tools v2.5.0-alpha
==========================

Voraussetzungen:
  - Python 3.9 oder neuer  (python.org/downloads)
  - pip (in der Regel mit Python mitgeliefert)
  - Firmware C auf dem Teensy geflasht

Starten:
  run.bat ausfuehren  (installiert Dependencies automatisch)
  oder: python aim_control.py

Verbindung:
  VID=0x1209  PID=0xABC0  Usage Page=0xFF00 (Custom HID)

Zurueck zu Firmware A:
  Teensy Loader + mim_firmware_v{version}.hex
  Dann steht das Web-Interface wieder zur Verfuegung.
