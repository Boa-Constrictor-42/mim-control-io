@echo off
echo MIM XInput Tools ? aim_control.py
echo.
echo Installing/updating dependencies ...
pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo ERROR: pip install fehlgeschlagen. Python 3.9+ und pip muessen installiert sein.
    pause
    exit /b 1
)
echo.
echo Starting AIM Control ...
python aim_control.py
pause
