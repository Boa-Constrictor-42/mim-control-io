#!/usr/bin/env python3
"""
AIM Control — MIM Mouse Input Modifier
Steuert AIM-Profil (5 Parameter + Button-Map + Mouse-Stick)
über Firmware C HID-Kanal (VID=0x1209 PID=0xABC0, Usage Page 0xFF00).
"""

import tkinter as tk
from tkinter import ttk, messagebox
import time
import struct as _struct
import os
import json

try:
    import hid as _hid
    _HAS_HID = True
except ImportError:
    _HAS_HID = False

# ── HID-Gerät ─────────────────────────────────────────────────────────────────
_HID_VID   = 0x1209
_HID_PID   = 0xABC0
_HID_UP    = 0xFF00
_HID_RPID  = 0x01

# ── AIM Wire-Protokoll ─────────────────────────────────────────────────────────
_CMD_READ_AIM  = 0x81
_CMD_WRITE_AIM = 0x01
# AIMProfile Payload (Bytes 6..47 = 42 Bytes):
#   _reserved[2]  2B
#   ema_alpha f  noise_gate f  sensitivity f  max_deflect f  curve_exp f
#   map[16]  16s
#   mouse_stick B  _pad2[3]  3B
_AIM_STRUCT = _struct.Struct('<2B5f16s4B')

# ── Parameter-Definitionen ────────────────────────────────────────────────────
_PARAMS = [
    {"key": "ema_alpha",   "label": "EMA-Alpha",  "min": 0.0,  "max": 1.0,  "step": 0.01, "fmt": ".2f", "unit": ""},
    {"key": "noise_gate",  "label": "Noise-Gate", "min": 0.0,  "max": 20.0, "step": 0.1,  "fmt": ".1f", "unit": "px/s"},
    {"key": "sensitivity", "label": "Sensitiv.",  "min": 0.1,  "max": 5.0,  "step": 0.05, "fmt": ".2f", "unit": "x"},
    {"key": "max_deflect", "label": "Max-Defl",   "min": 0.1,  "max": 1.0,  "step": 0.01, "fmt": ".2f", "unit": ""},
    {"key": "curve_exp",   "label": "Curve-Exp",  "min": 0.5,  "max": 3.0,  "step": 0.05, "fmt": ".2f", "unit": ""},
]

_BTN_NAMES = [
    "A",      "B",       "X",       "Y",
    "LB",     "RB",      "LT",      "RT",
    "DPad↑",  "DPad↓",  "DPad←",  "DPad→",
    "View",   "Menu",    "L3",      "R3",
]

# HID Usage ID → lesbarer Name
_KEY_NAMES = {
    0x00: "—",
    0x04: "A",     0x05: "B",     0x06: "C",     0x07: "D",     0x08: "E",
    0x09: "F",     0x0A: "G",     0x0B: "H",     0x0C: "I",     0x0D: "J",
    0x0E: "K",     0x0F: "L",     0x10: "M",     0x11: "N",     0x12: "O",
    0x13: "P",     0x14: "Q",     0x15: "R",     0x16: "S",     0x17: "T",
    0x18: "U",     0x19: "V",     0x1A: "W",     0x1B: "X",     0x1C: "Y",
    0x1D: "Z",
    0x1E: "1",     0x1F: "2",     0x20: "3",     0x21: "4",     0x22: "5",
    0x23: "6",     0x24: "7",     0x25: "8",     0x26: "9",     0x27: "0",
    0x28: "Enter", 0x29: "Esc",   0x2A: "BkSp",  0x2B: "Tab",   0x2C: "Space",
    0x2D: "-",     0x2E: "=",     0x2F: "[",     0x30: "]",     0x31: "\\",
    0x33: ";",     0x34: "'",     0x35: "`",     0x36: ",",     0x37: ".",
    0x38: "/",
    0x3A: "F1",    0x3B: "F2",    0x3C: "F3",    0x3D: "F4",    0x3E: "F5",
    0x3F: "F6",    0x40: "F7",    0x41: "F8",    0x42: "F9",    0x43: "F10",
    0x44: "F11",   0x45: "F12",
    0x4F: "→",     0x50: "←",     0x51: "↓",     0x52: "↑",
    0xE0: "LCtrl", 0xE1: "LShift", 0xE2: "LAlt",  0xE3: "LMeta",
    0xE4: "RCtrl", 0xE5: "RShift", 0xE6: "RAlt",  0xE7: "RMeta",
    0xF0: "M:LMB", 0xF1: "M:RMB", 0xF2: "M:MMB",
    0xF3: "M:B4",  0xF4: "M:B5",
}

def _key_name(code: int) -> str:
    return _KEY_NAMES.get(code, f"0x{code:02X}")

_SETTINGS_DIR  = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "MIM")
_SETTINGS_FILE = os.path.join(_SETTINGS_DIR, "aim_settings.json")


# ── Haupt-App ─────────────────────────────────────────────────────────────────
class AimControlApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("AIM Control — MIM")
        root.configure(bg="#111111")
        root.resizable(False, False)

        self._hid_dev  = None
        self._connected = False

        # Tkinter-Variablen
        self._param_vars:   dict[str, tk.DoubleVar] = {}
        self._map_vars:     list[tk.StringVar]       = []
        self._map_labels:   list[tk.Label]           = []
        self._stick_var     = tk.IntVar(value=1)
        self._status_var    = tk.StringVar(value="Disconnected")

        self._settings = self._load_settings()
        self._build_ui()

    # ── Persistenz ────────────────────────────────────────────────────────────
    def _load_settings(self) -> dict:
        try:
            with open(_SETTINGS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def _save_settings(self):
        data: dict = {}
        for p in _PARAMS:
            data[p["key"]] = self._param_vars[p["key"]].get()
        data["mouse_stick"] = self._stick_var.get()
        data["map"] = [self._map_vars[i].get() for i in range(16)]
        try:
            os.makedirs(_SETTINGS_DIR, exist_ok=True)
            with open(_SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass

    # ── UI-Aufbau ─────────────────────────────────────────────────────────────
    def _build_ui(self):
        pad = {"padx": 10, "pady": 4}

        # ── Verbindungs-Leiste ────────────────────────────────────────────────
        conn = tk.Frame(self.root, bg="#111111")
        conn.pack(fill=tk.X, **pad)

        self._conn_btn = tk.Button(
            conn, text="Connect", width=12,
            command=self._toggle_connection,
            bg="#333333", fg="#FFFFFF", activebackground="#555555",
        )
        self._conn_btn.pack(side=tk.LEFT)

        self._status_lbl = tk.Label(
            conn, textvariable=self._status_var,
            width=22, relief=tk.SUNKEN, anchor="w",
            font=("Consolas", 9), bg="#DDDDDD",
        )
        self._status_lbl.pack(side=tk.LEFT, padx=8)

        tk.Label(conn, text=f"VID={_HID_VID:#06x}  PID={_HID_PID:#06x}",
                 bg="#111111", fg="#555555", font=("Consolas", 8)).pack(side=tk.LEFT)

        # ── 5 Float-Parameter ─────────────────────────────────────────────────
        pf = tk.LabelFrame(self.root, text="Parameter", padx=8, pady=6,
                           bg="#1A1A1A", fg="#CCCCCC", font=("Consolas", 9))
        pf.pack(fill=tk.X, padx=10, pady=(0, 4))

        for p in _PARAMS:
            key  = p["key"]
            init = float(self._settings.get(key, (p["min"] + p["max"]) / 2))
            var  = tk.DoubleVar(value=init)
            self._param_vars[key] = var

            row = tk.Frame(pf, bg="#1A1A1A")
            row.pack(fill=tk.X, pady=2)

            unit_str = f" [{p['unit']}]" if p["unit"] else ""
            tk.Label(row, text=f"{p['label']}{unit_str}",
                     width=16, anchor="w", bg="#1A1A1A", fg="#AAAAAA",
                     font=("Consolas", 9)).pack(side=tk.LEFT)

            sl = tk.Scale(
                row, variable=var,
                from_=p["min"], to=p["max"],
                resolution=p["step"],
                orient=tk.HORIZONTAL, length=260,
                showvalue=False, bg="#1A1A1A", fg="#AAAAAA",
                troughcolor="#333333", highlightthickness=0,
            )
            sl.pack(side=tk.LEFT, padx=4)

            ent = tk.Entry(row, width=7, font=("Consolas", 10),
                           bg="#222222", fg="#FFFFFF", insertbackground="white")
            ent.insert(0, f"{init:{p['fmt']}}")
            ent.pack(side=tk.LEFT, padx=2)
            ent.bind("<Return>",   lambda e, k=key, en=ent, pd=p: self._on_entry(k, en, pd))
            ent.bind("<FocusOut>", lambda e, k=key, en=ent, pd=p: self._on_entry(k, en, pd))

            def _sync(val, en=ent, pd=p):
                cur = en.get()
                new = f"{float(val):{pd['fmt']}}"
                if cur != new:
                    en.delete(0, tk.END)
                    en.insert(0, new)
            var.trace_add("write", lambda *_, v=var, cb=_sync: cb(v.get()))

        # ── Mouse-Stick ───────────────────────────────────────────────────────
        sf = tk.Frame(self.root, bg="#111111")
        sf.pack(fill=tk.X, padx=10, pady=(0, 4))

        tk.Label(sf, text="Mouse → Stick:", width=16, anchor="w",
                 bg="#111111", fg="#AAAAAA", font=("Consolas", 9)).pack(side=tk.LEFT)

        init_stick = int(self._settings.get("mouse_stick", 1))
        self._stick_var.set(init_stick)
        for val, label in ((1, "Right Stick (default)"), (0, "Left Stick")):
            tk.Radiobutton(
                sf, text=label, variable=self._stick_var, value=val,
                bg="#111111", fg="#AAAAAA", selectcolor="#333333",
                activebackground="#111111", activeforeground="#FFFFFF",
                font=("Consolas", 9),
            ).pack(side=tk.LEFT, padx=8)

        # ── Button-Map ────────────────────────────────────────────────────────
        mf = tk.LabelFrame(
            self.root,
            text="Button Map  —  Hex-Code  (0x2C=Space  0xE0=LCtrl  0xF0=M:LMB  0x00=off)",
            padx=8, pady=6,
            bg="#1A1A1A", fg="#CCCCCC", font=("Consolas", 8),
        )
        mf.pack(fill=tk.X, padx=10, pady=(0, 4))

        saved_map = self._settings.get("map", ["0x00"] * 16)

        COLS = 4
        for i, name in enumerate(_BTN_NAMES):
            init_code = saved_map[i] if i < len(saved_map) else "0x00"
            var = tk.StringVar(value=init_code)
            self._map_vars.append(var)

            cell = tk.Frame(mf, bg="#1A1A1A")
            cell.grid(row=i // COLS, column=i % COLS, padx=6, pady=2, sticky="w")

            tk.Label(cell, text=f"{name:<7}", width=7, anchor="w",
                     bg="#1A1A1A", fg="#888888", font=("Consolas", 9)).pack(side=tk.LEFT)

            ent = tk.Entry(cell, textvariable=var, width=6, font=("Consolas", 9),
                           bg="#222222", fg="#FFFFFF", insertbackground="white")
            ent.pack(side=tk.LEFT, padx=2)
            ent.bind("<Return>",   lambda e, idx=i: self._on_map_entry(idx))
            ent.bind("<FocusOut>", lambda e, idx=i: self._on_map_entry(idx))

            # Initial code → code versuchen zu parsen
            try:
                code = int(init_code, 0)
            except ValueError:
                code = 0
            lbl = tk.Label(cell, text=_key_name(code), width=9, anchor="w",
                           bg="#1A1A1A", fg="#55AAFF", font=("Consolas", 8))
            lbl.pack(side=tk.LEFT)
            self._map_labels.append(lbl)

        # ── Aktions-Buttons ───────────────────────────────────────────────────
        af = tk.Frame(self.root, bg="#111111")
        af.pack(fill=tk.X, padx=10, pady=6)

        tk.Button(af, text="Read AIM",  width=12, command=self._read_aim,
                  bg="#334455", fg="#FFFFFF").pack(side=tk.LEFT, padx=4)
        tk.Button(af, text="Write AIM", width=12, command=self._write_aim,
                  bg="#335544", fg="#FFFFFF").pack(side=tk.LEFT, padx=4)
        tk.Button(af, text="Defaults",  width=10, command=self._load_defaults,
                  bg="#443322", fg="#FFFFFF").pack(side=tk.LEFT, padx=4)

        tk.Button(af, text="Save local", width=12, command=self._save_settings,
                  bg="#222222", fg="#AAAAAA").pack(side=tk.RIGHT, padx=4)

        # ── Log ───────────────────────────────────────────────────────────────
        lf = tk.Frame(self.root, bg="#111111")
        lf.pack(fill=tk.X, padx=10, pady=(0, 6))

        self._log_box = tk.Text(
            lf, height=5, width=60,
            bg="#0A0A0A", fg="#AAFFAA", font=("Consolas", 8),
            state=tk.DISABLED, wrap=tk.NONE,
        )
        sb = tk.Scrollbar(lf, command=self._log_box.yview)
        self._log_box.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self._log_box.pack(fill=tk.X)

        if not _HAS_HID:
            self._log("WARNUNG: 'hid' Paket nicht installiert (pip install hid)\n", "#FFAAAA")

    # ── Event-Handler ─────────────────────────────────────────────────────────
    def _on_entry(self, key: str, entry: tk.Entry, pdef: dict):
        try:
            v = float(entry.get())
            v = max(pdef["min"], min(pdef["max"], v))
            self._param_vars[key].set(v)
        except ValueError:
            entry.delete(0, tk.END)
            entry.insert(0, f"{self._param_vars[key].get():{pdef['fmt']}}")

    def _on_map_entry(self, idx: int):
        raw = self._map_vars[idx].get().strip()
        try:
            code = int(raw, 0) & 0xFF
            self._map_vars[idx].set(f"0x{code:02X}")
            self._map_labels[idx].config(text=_key_name(code))
        except ValueError:
            pass

    def _load_defaults(self):
        defaults = {
            "ema_alpha":   0.3,
            "noise_gate":  2.0,
            "sensitivity": 1.0,
            "max_deflect": 0.75,
            "curve_exp":   1.0,
        }
        for k, v in defaults.items():
            if k in self._param_vars:
                self._param_vars[k].set(v)
        self._stick_var.set(1)

        default_map = [
            "0x2C", "0xE0", "0x15", "0x09",  # A=Space B=LCtrl X=R Y=F
            "0x14", "0x08", "0xF1", "0xF0",  # LB=Q RB=E LT=M:RMB RT=M:LMB
            "0x1E", "0x1F", "0x20", "0x21",  # DPad↑=1 ↓=2 ←=3 →=4
            "0x2B", "0x29", "0xE1", "0xF2",  # View=Tab Menu=Esc L3=LShift R3=M:MMB
        ]
        for i, v in enumerate(default_map):
            self._map_vars[i].set(v)
            try:
                self._map_labels[i].config(text=_key_name(int(v, 0)))
            except ValueError:
                pass

    # ── HID-Verbindung ────────────────────────────────────────────────────────
    def _toggle_connection(self):
        if self._connected:
            self._disconnect()
        else:
            self._connect()

    def _connect(self):
        if not _HAS_HID:
            self._log("FEHLER: hid-Paket fehlt (pip install hid)\n", "#FFAAAA")
            return
        devs = [d for d in _hid.enumerate(_HID_VID, _HID_PID)
                if d.get("usage_page") == _HID_UP]
        if not devs:
            self._set_status("Nicht gefunden", "#FFAAAA")
            self._log(f"Gerät VID={_HID_VID:#06x} PID={_HID_PID:#06x} UP={_HID_UP:#06x} nicht gefunden.\n",
                      "#FFAAAA")
            return
        try:
            self._hid_dev = _hid.device()
            self._hid_dev.open_path(devs[0]["path"])
            self._hid_dev.set_nonblocking(0)
            self._connected = True
            self._conn_btn.config(text="Disconnect")
            self._set_status("Connected (HID)", "#AAFFAA")
            self._log(f"Verbunden: {devs[0].get('manufacturer_string', '')} | "
                      f"{devs[0].get('product_string', '')}\n")
            self._read_aim()
        except Exception as e:
            self._set_status("Fehler", "#FFAAAA")
            self._log(f"Verbindungsfehler: {e}\n", "#FFAAAA")
            self._hid_dev = None

    def _disconnect(self):
        if self._hid_dev:
            try:
                self._hid_dev.close()
            except Exception:
                pass
            self._hid_dev = None
        self._connected = False
        self._conn_btn.config(text="Connect")
        self._set_status("Disconnected", "#DDDDDD")
        self._log("Getrennt.\n")

    # ── HID Read / Write ──────────────────────────────────────────────────────
    def _pack_payload(self) -> bytes:
        ema   = float(self._param_vars["ema_alpha"].get())
        ng    = float(self._param_vars["noise_gate"].get())
        sens  = float(self._param_vars["sensitivity"].get())
        defl  = float(self._param_vars["max_deflect"].get())
        exp_  = float(self._param_vars["curve_exp"].get())
        stick = int(self._stick_var.get())
        map_b = bytearray(16)
        for i in range(16):
            try:
                map_b[i] = int(self._map_vars[i].get(), 0) & 0xFF
            except ValueError:
                map_b[i] = 0
        return _AIM_STRUCT.pack(0, 0, ema, ng, sens, defl, exp_,
                                bytes(map_b), stick, 0, 0, 0)

    def _unpack_payload(self, payload: bytes):
        (_, _, ema, ng, sens, defl, exp_,
         map_b, stick, *_) = _AIM_STRUCT.unpack(payload[:_AIM_STRUCT.size])
        self._param_vars["ema_alpha"].set(round(ema, 4))
        self._param_vars["noise_gate"].set(round(ng, 4))
        self._param_vars["sensitivity"].set(round(sens, 4))
        self._param_vars["max_deflect"].set(round(defl, 4))
        self._param_vars["curve_exp"].set(round(exp_, 4))
        self._stick_var.set(stick)
        for i, b in enumerate(map_b[:16]):
            self._map_vars[i].set(f"0x{b:02X}")
            self._map_labels[i].config(text=_key_name(b))

    def _read_aim(self):
        if not self._hid_dev:
            self._log("Nicht verbunden.\n", "#FFAAAA")
            return
        try:
            req = bytes([_HID_RPID, _CMD_READ_AIM]) + b'\x00' * 62
            self._hid_dev.send_feature_report(req[:64])
            time.sleep(0.05)
            resp = bytes(self._hid_dev.get_feature_report(_HID_RPID, 65) or b'')
            if len(resp) < 2 + _AIM_STRUCT.size or resp[1] != _CMD_READ_AIM:
                self._log(f"Read AIM: unerwartete Antwort (len={len(resp)}"
                          f" cmd={resp[1] if len(resp)>1 else '?'})\n", "#FFAAAA")
                return
            self._unpack_payload(resp[2:])
            self._log("Read AIM OK\n")
        except Exception as e:
            self._log(f"Read AIM Fehler: {e}\n", "#FFAAAA")

    def _write_aim(self):
        if not self._hid_dev:
            self._log("Nicht verbunden.\n", "#FFAAAA")
            return
        try:
            payload = self._pack_payload()
            data = bytes([_HID_RPID, _CMD_WRITE_AIM]) + payload
            data = (data + b'\x00' * 64)[:64]
            self._hid_dev.send_feature_report(data)
            self._log("Write AIM OK\n")
            self._save_settings()
        except Exception as e:
            self._log(f"Write AIM Fehler: {e}\n", "#FFAAAA")

    # ── Hilfsmethoden ─────────────────────────────────────────────────────────
    def _set_status(self, text: str, bg: str = "#DDDDDD"):
        self._status_var.set(text)
        self._status_lbl.config(bg=bg)

    def _log(self, msg: str, fg: str = "#AAFFAA"):
        self._log_box.config(state=tk.NORMAL)
        self._log_box.insert(tk.END, msg)
        self._log_box.see(tk.END)
        self._log_box.config(state=tk.DISABLED)


def main():
    root = tk.Tk()
    app = AimControlApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
