#!/usr/bin/env python3
"""
AIM / CIM Control — MIM Mouse Input Modifier (Firmware C)
Steuert AIM-Profil und CIM-Profil über Firmware C HID-Kanal.
VID=0x1209  PID=0xABC0  Usage Page=0xFF00
"""

import tkinter as tk
from tkinter import ttk
import time
import struct as _struct
import os
import json

try:
    import hid as _hid
    _HAS_HID = True
except ImportError:
    _HAS_HID = False

try:
    import numpy as np
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    _HAS_MPL = True
except ImportError:
    _HAS_MPL = False

# ── HID-Gerät ─────────────────────────────────────────────────────────────────
_HID_VID  = 0x1209
_HID_PID  = 0xABC0
_HID_UP   = 0xFF00
_HID_RPID = 0x01

# ── Mode-Bytes ────────────────────────────────────────────────────────────────
_MODE_AIM = 0x02
_MODE_CIM = 0x03

# ── HID-Commands ──────────────────────────────────────────────────────────────
_CMD_READ_AIM  = 0x81
_CMD_WRITE_AIM = 0x01
_CMD_READ_CIM  = 0x82
_CMD_WRITE_CIM = 0x02
_CMD_SET_MODE  = 0x10
_CMD_GET_MODE  = 0x90

# ── Wire-Structs ──────────────────────────────────────────────────────────────
# AIMProfile Payload (Bytes 6..47 = 42 Bytes):
#   _reserved[2] 2B  ema f  noise_gate f  sensitivity f  max_deflect f  curve_exp f
#   map[16] 16s  mouse_stick B  _pad2[3] 3B
_AIM_STRUCT = _struct.Struct('<2B5f16s4B')

# CIMProfile Payload (Bytes 6..63 = 58 Bytes):
#   sigmaPct f  rfSpread f  tEndMs I  vX[7] 7h  vY[7] 7h
#   rfHz f  xDelay H  yDelay H
#   rfDutyPct B  axis_lx B  axis_ly B  fire_btn B  _res BB  cimSens f
_CIM_STRUCT = _struct.Struct('<ffI7h7hfHHBBBBBBf')

# ── AIM-Parameter ─────────────────────────────────────────────────────────────
_AIM_PARAMS = [
    {"key": "ema_alpha",   "label": "EMA-Alpha",  "min": 0.0,  "max": 1.0,  "step": 0.01, "fmt": ".2f", "unit": ""},
    {"key": "noise_gate",  "label": "Noise-Gate", "min": 0.0,  "max": 20.0, "step": 0.1,  "fmt": ".1f", "unit": "px/s"},
    {"key": "sensitivity", "label": "Sensitiv.",  "min": 0.1,  "max": 5.0,  "step": 0.05, "fmt": ".2f", "unit": "x"},
    {"key": "max_deflect", "label": "Max-Defl",   "min": 0.1,  "max": 1.0,  "step": 0.01, "fmt": ".2f", "unit": ""},
    {"key": "curve_exp",   "label": "Curve-Exp",  "min": 0.5,  "max": 3.0,  "step": 0.05, "fmt": ".2f", "unit": ""},
]
_AIM_DEFAULTS = {
    "ema_alpha": 0.3, "noise_gate": 2.0, "sensitivity": 1.0,
    "max_deflect": 0.75, "curve_exp": 1.0, "mouse_stick": 1,
    "map": ["0x2C","0xE0","0x15","0x09","0x14","0x08","0xF1","0xF0",
            "0x1E","0x1F","0x20","0x21","0x2B","0x29","0xE1","0xF2"],
}

# ── CIM-Parameter ─────────────────────────────────────────────────────────────
# Reihenfolge entspricht dem Struct-Layout für den Index-Zugriff in _pack_cim()
_CIM_PARAMS = [
    # 0-6: vX
    {"key": "vX0", "label": "vX0", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vX1", "label": "vX1", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vX2", "label": "vX2", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vX3", "label": "vX3", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vX4", "label": "vX4", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vX5", "label": "vX5", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vX6", "label": "vX6", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    # 7-13: vY
    {"key": "vY0", "label": "vY0", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vY1", "label": "vY1", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vY2", "label": "vY2", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vY3", "label": "vY3", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vY4", "label": "vY4", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vY5", "label": "vY5", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    {"key": "vY6", "label": "vY6", "min": -500., "max": 500., "step": 1., "fmt": ".0f", "unit": "px/s"},
    # 14-15: timing
    {"key": "xDelay",    "label": "X-Delay",  "min": 0.,   "max": 3000.,  "step": 5.,  "fmt": ".0f", "unit": "ms"},
    {"key": "yDelay",    "label": "Y-Delay",  "min": 0.,   "max": 3000.,  "step": 5.,  "fmt": ".0f", "unit": "ms"},
    # 16-20: scalar params
    {"key": "sigmaPct",  "label": "Sigma",    "min": 0.1,  "max": 15.,    "step": 0.1, "fmt": ".1f", "unit": "%"},
    {"key": "rfHz",      "label": "RF-Hz",    "min": 0.,   "max": 20.,    "step": 0.1, "fmt": ".1f", "unit": "Hz"},
    {"key": "rfSpread",  "label": "RF-Sprd",  "min": 0.1,  "max": 15.,    "step": 0.1, "fmt": ".1f", "unit": "%"},
    {"key": "rfDutyPct", "label": "RF-Duty",  "min": 5.,   "max": 95.,    "step": 5.,  "fmt": ".0f", "unit": "%"},
    {"key": "tEndMs",    "label": "T-End",    "min": 500., "max": 10000., "step": 25., "fmt": ".0f", "unit": "ms"},
]
_CIM_DEFAULTS = {
    "vX0": 0., "vX1": 0., "vX2": 0., "vX3": 0., "vX4": 0., "vX5": 0., "vX6": 0.,
    "vY0": 0., "vY1": 0., "vY2": 0., "vY3": 0., "vY4": 0., "vY5": 0., "vY6": 0.,
    "xDelay": 0., "yDelay": 0., "sigmaPct": 1.0, "rfHz": 0.,
    "rfSpread": 1.0, "rfDutyPct": 70., "tEndMs": 5000.,
}

# ── Button-Map ────────────────────────────────────────────────────────────────
_BTN_NAMES = [
    "A",      "B",       "X",       "Y",
    "LB",     "RB",      "LT",      "RT",
    "DPad↑",  "DPad↓",  "DPad←",  "DPad→",
    "View",   "Menu",    "L3",      "R3",
]
_KEY_NAMES = {
    0x00: "—",
    0x04: "A",     0x05: "B",     0x06: "C",     0x07: "D",     0x08: "E",
    0x09: "F",     0x0A: "G",     0x0B: "H",     0x0C: "I",     0x0D: "J",
    0x0E: "K",     0x0F: "L",     0x10: "M",     0x11: "N",     0x12: "O",
    0x13: "P",     0x14: "Q",     0x15: "R",     0x16: "S",     0x17: "T",
    0x18: "U",     0x19: "V",     0x1A: "W",     0x1B: "X",     0x1C: "Y",
    0x1D: "Z",
    0x1E: "1",     0x1F: "2",     0x20: "3",     0x21: "4",     0x22: "5",
    0x23: "6",     0x24: "7",     0x25: "8",     0x26: "9",     0x27: "0",
    0x28: "Enter", 0x29: "Esc",   0x2A: "BkSp",  0x2B: "Tab",   0x2C: "Space",
    0x2D: "-",     0x2E: "=",     0x2F: "[",     0x30: "]",     0x31: "\\",
    0x33: ";",     0x34: "'",     0x35: "`",     0x36: ",",     0x37: ".",
    0x38: "/",
    0x3A: "F1",    0x3B: "F2",    0x3C: "F3",    0x3D: "F4",    0x3E: "F5",
    0x3F: "F6",    0x40: "F7",    0x41: "F8",    0x42: "F9",    0x43: "F10",
    0x44: "F11",   0x45: "F12",
    0x4F: "→",     0x50: "←",     0x51: "↓",     0x52: "↑",
    0xE0: "LCtrl", 0xE1: "LShift", 0xE2: "LAlt",  0xE3: "LMeta",
    0xE4: "RCtrl", 0xE5: "RShift", 0xE6: "RAlt",  0xE7: "RMeta",
    0xF0: "M:LMB", 0xF1: "M:RMB", 0xF2: "M:MMB",
    0xF3: "M:B4",  0xF4: "M:B5",
}

def _key_name(code: int) -> str:
    return _KEY_NAMES.get(code, f"0x{code:02X}")

# ── Persistenz ────────────────────────────────────────────────────────────────
_SETTINGS_DIR  = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "MIM")
_SETTINGS_FILE = os.path.join(_SETTINGS_DIR, "aim_settings.json")

# ── Farb-Konstanten ───────────────────────────────────────────────────────────
_BG       = "#111111"
_BG2      = "#1A1A1A"
_FG       = "#CCCCCC"
_DIM      = "#888888"
_TROUGH   = "#333333"
_ENTRY_BG = "#222222"


# ══════════════════════════════════════════════════════════════════════════════
class AimControlApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("AIM / CIM Control — MIM Firmware C")
        root.configure(bg=_BG)
        root.resizable(False, False)

        self._hid_dev   = None
        self._connected = False
        self._tab_init  = False   # suppresses tab-change SET_MODE during connect

        # AIM Tkinter-Variablen
        self._aim_vars:   dict[str, tk.DoubleVar] = {}
        self._map_vars:   list[tk.StringVar]       = []
        self._map_labels: list[tk.Label]           = []
        self._stick_var   = tk.IntVar(value=1)
        self._status_var  = tk.StringVar(value="Disconnected")

        # CIM Tkinter-Variablen + Round-Trip-Cache
        self._cim_vars:      dict[str, tk.DoubleVar] = {}
        self._hid_extra_cim: dict = {}

        self._settings = self._load_settings()
        self._build_ui()

    # ── Persistenz ────────────────────────────────────────────────────────────
    def _load_settings(self) -> dict:
        try:
            with open(_SETTINGS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def _save_settings(self):
        data = dict(self._settings)  # preserve unknown keys
        for p in _AIM_PARAMS:
            data[p["key"]] = self._aim_vars[p["key"]].get()
        data["mouse_stick"] = self._stick_var.get()
        data["map"] = [self._map_vars[i].get() for i in range(16)]
        cim_data = {}
        for p in _CIM_PARAMS:
            cim_data[p["key"]] = self._cim_vars[p["key"]].get()
        data["cim"] = cim_data
        data["last_mode"] = "CIM" if self._active_tab() == 1 else "AIM"
        try:
            os.makedirs(_SETTINGS_DIR, exist_ok=True)
            with open(_SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass

    def _active_tab(self) -> int:
        """Returns 0 for AIM tab, 1 for CIM tab."""
        try:
            return self._nb.index(self._nb.select())
        except Exception:
            return 0

    # ── UI-Aufbau ─────────────────────────────────────────────────────────────
    def _build_ui(self):
        pad = {"padx": 10, "pady": 4}

        # ── Verbindungs-Leiste ────────────────────────────────────────────────
        conn = tk.Frame(self.root, bg=_BG)
        conn.pack(fill=tk.X, **pad)

        self._conn_btn = tk.Button(
            conn, text="Connect", width=12,
            command=self._toggle_connection,
            bg="#333333", fg="#FFFFFF", activebackground="#555555",
        )
        self._conn_btn.pack(side=tk.LEFT)

        self._status_lbl = tk.Label(
            conn, textvariable=self._status_var,
            width=24, relief=tk.SUNKEN, anchor="w",
            font=("Consolas", 9), bg="#DDDDDD",
        )
        self._status_lbl.pack(side=tk.LEFT, padx=8)

        tk.Label(conn, text=f"VID={_HID_VID:#06x}  PID={_HID_PID:#06x}",
                 bg=_BG, fg="#555555", font=("Consolas", 8)).pack(side=tk.LEFT)

        # ── Notebook (AIM / CIM Tabs) ─────────────────────────────────────────
        style = ttk.Style()
        style.theme_use("default")
        style.configure("TNotebook",        background=_BG,  borderwidth=0)
        style.configure("TNotebook.Tab",    background="#222222", foreground=_FG,
                        padding=[12, 4], font=("Consolas", 9))
        style.map("TNotebook.Tab",
                  background=[("selected", "#334455")],
                  foreground=[("selected", "#FFFFFF")])

        self._nb = ttk.Notebook(self.root)
        self._nb.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 4))

        self._aim_tab = tk.Frame(self._nb, bg=_BG)
        self._cim_tab = tk.Frame(self._nb, bg=_BG)
        self._nb.add(self._aim_tab, text="  AIM  ")
        self._nb.add(self._cim_tab, text="  CIM  ")
        self._nb.bind("<<NotebookTabChanged>>", self._on_tab_change)

        self._build_aim_tab(self._aim_tab)
        self._build_cim_tab(self._cim_tab)

        # ── Log ───────────────────────────────────────────────────────────────
        lf = tk.Frame(self.root, bg=_BG)
        lf.pack(fill=tk.X, padx=10, pady=(0, 6))

        self._log_box = tk.Text(
            lf, height=4, width=70,
            bg="#0A0A0A", fg="#AAFFAA", font=("Consolas", 8),
            state=tk.DISABLED, wrap=tk.NONE,
        )
        sb = tk.Scrollbar(lf, command=self._log_box.yview)
        self._log_box.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self._log_box.pack(fill=tk.X)

        if not _HAS_HID:
            self._log("WARNUNG: 'hid' Paket nicht installiert (pip install hid)\n", "#FFAAAA")

        # Initial-Tab aus gespeichertem last_mode
        if self._settings.get("last_mode") == "CIM":
            self._tab_init = True
            self._nb.select(1)
            self._tab_init = False

    # ── AIM-Tab ───────────────────────────────────────────────────────────────
    def _build_aim_tab(self, parent: tk.Frame):
        pad = {"padx": 8, "pady": 2}

        # 5 Float-Parameter
        pf = tk.LabelFrame(parent, text="Parameter", padx=8, pady=6,
                           bg=_BG2, fg=_FG, font=("Consolas", 9))
        pf.pack(fill=tk.X, **pad)

        saved = self._settings
        for p in _AIM_PARAMS:
            key  = p["key"]
            init = float(saved.get(key, _AIM_DEFAULTS.get(key, (p["min"] + p["max"]) / 2)))
            var  = tk.DoubleVar(value=init)
            self._aim_vars[key] = var
            self._build_slider_row(pf, p, var)

        # AIM Response Curve
        self._aim_ax     = None
        self._aim_canvas = None
        self._build_aim_graph(parent)

        # Mouse-Stick
        sf = tk.Frame(parent, bg=_BG)
        sf.pack(fill=tk.X, padx=8, pady=(2, 2))
        tk.Label(sf, text="Mouse → Stick:", width=16, anchor="w",
                 bg=_BG, fg=_DIM, font=("Consolas", 9)).pack(side=tk.LEFT)
        init_stick = int(saved.get("mouse_stick", 1))
        self._stick_var.set(init_stick)
        for val, label in ((1, "Right Stick (default)"), (0, "Left Stick")):
            tk.Radiobutton(
                sf, text=label, variable=self._stick_var, value=val,
                bg=_BG, fg=_DIM, selectcolor="#333333",
                activebackground=_BG, activeforeground="#FFFFFF",
                font=("Consolas", 9),
            ).pack(side=tk.LEFT, padx=8)

        # Button-Map
        mf = tk.LabelFrame(
            parent,
            text="Button Map  —  Hex-Code  (0x2C=Space  0xE0=LCtrl  0xF0=M:LMB  0x00=off)",
            padx=8, pady=6, bg=_BG2, fg=_FG, font=("Consolas", 8),
        )
        mf.pack(fill=tk.X, padx=8, pady=(2, 4))

        saved_map = saved.get("map", _AIM_DEFAULTS["map"])
        COLS = 4
        for i, name in enumerate(_BTN_NAMES):
            init_code = saved_map[i] if i < len(saved_map) else "0x00"
            var = tk.StringVar(value=init_code)
            self._map_vars.append(var)

            cell = tk.Frame(mf, bg=_BG2)
            cell.grid(row=i // COLS, column=i % COLS, padx=6, pady=2, sticky="w")

            tk.Label(cell, text=f"{name:<7}", width=7, anchor="w",
                     bg=_BG2, fg=_DIM, font=("Consolas", 9)).pack(side=tk.LEFT)

            ent = tk.Entry(cell, textvariable=var, width=6, font=("Consolas", 9),
                           bg=_ENTRY_BG, fg="#FFFFFF", insertbackground="white")
            ent.pack(side=tk.LEFT, padx=2)
            ent.bind("<Return>",   lambda e, idx=i: self._on_map_entry(idx))
            ent.bind("<FocusOut>", lambda e, idx=i: self._on_map_entry(idx))

            try:
                code = int(init_code, 0)
            except ValueError:
                code = 0
            lbl = tk.Label(cell, text=_key_name(code), width=9, anchor="w",
                           bg=_BG2, fg="#55AAFF", font=("Consolas", 8))
            lbl.pack(side=tk.LEFT)
            self._map_labels.append(lbl)

        # Aktions-Buttons AIM
        af = tk.Frame(parent, bg=_BG)
        af.pack(fill=tk.X, padx=8, pady=6)
        tk.Button(af, text="Read AIM",  width=12, command=self._read_aim,
                  bg="#334455", fg="#FFFFFF").pack(side=tk.LEFT, padx=4)
        tk.Button(af, text="Write AIM", width=12, command=self._write_aim,
                  bg="#335544", fg="#FFFFFF").pack(side=tk.LEFT, padx=4)
        tk.Button(af, text="Defaults",  width=10, command=self._load_aim_defaults,
                  bg="#443322", fg="#FFFFFF").pack(side=tk.LEFT, padx=4)
        tk.Button(af, text="Save local", width=12, command=self._save_settings,
                  bg="#222222", fg="#AAAAAA").pack(side=tk.RIGHT, padx=4)

    # ── CIM-Tab ───────────────────────────────────────────────────────────────
    def _build_cim_tab(self, parent: tk.Frame):
        pad = {"padx": 8, "pady": 2}
        saved_cim = self._settings.get("cim", {})

        for p in _CIM_PARAMS:
            key  = p["key"]
            init = float(saved_cim.get(key, _CIM_DEFAULTS.get(key, 0.0)))
            self._cim_vars[key] = tk.DoubleVar(value=init)

        # ── Velocity Spline (vX + vY side by side) ───────────────────────────
        sf = tk.LabelFrame(parent, text="Velocity Spline", padx=8, pady=4,
                           bg=_BG2, fg=_FG, font=("Consolas", 9))
        sf.pack(fill=tk.X, **pad)

        hdr = tk.Frame(sf, bg=_BG2)
        hdr.pack(fill=tk.X)
        for col, label in enumerate(("", "X  axis", "", "", "Y  axis", "")):
            tk.Label(hdr, text=label, width=8 if col in (1, 4) else (2 if col in (0, 3) else 6),
                     anchor="w", bg=_BG2, fg=_DIM, font=("Consolas", 8)).grid(row=0, column=col)

        SLIDER_LEN = 180
        for n in range(7):
            row = tk.Frame(sf, bg=_BG2)
            row.pack(fill=tk.X, pady=1)

            px = _CIM_PARAMS[n]      # vX[n]
            py = _CIM_PARAMS[7 + n]  # vY[n]

            # vX label
            tk.Label(row, text=f"vX{n}", width=4, anchor="e",
                     bg=_BG2, fg=_DIM, font=("Consolas", 8)).pack(side=tk.LEFT)
            # vX slider
            sl_x = tk.Scale(row, variable=self._cim_vars[px["key"]],
                            from_=px["min"], to=px["max"], resolution=px["step"],
                            orient=tk.HORIZONTAL, length=SLIDER_LEN, showvalue=False,
                            bg=_BG2, fg=_DIM, troughcolor=_TROUGH, highlightthickness=0)
            sl_x.pack(side=tk.LEFT, padx=2)
            # vX entry
            ex = tk.Entry(row, width=6, font=("Consolas", 9),
                          bg=_ENTRY_BG, fg="#FFFFFF", insertbackground="white")
            ex.insert(0, f"{self._cim_vars[px['key']].get():.0f}")
            ex.pack(side=tk.LEFT, padx=2)
            self._wire_cim_slider(px, self._cim_vars[px["key"]], ex)

            tk.Label(row, text=" ", width=3, bg=_BG2).pack(side=tk.LEFT)

            # vY label
            tk.Label(row, text=f"vY{n}", width=4, anchor="e",
                     bg=_BG2, fg=_DIM, font=("Consolas", 8)).pack(side=tk.LEFT)
            # vY slider
            sl_y = tk.Scale(row, variable=self._cim_vars[py["key"]],
                            from_=py["min"], to=py["max"], resolution=py["step"],
                            orient=tk.HORIZONTAL, length=SLIDER_LEN, showvalue=False,
                            bg=_BG2, fg=_DIM, troughcolor=_TROUGH, highlightthickness=0)
            sl_y.pack(side=tk.LEFT, padx=2)
            # vY entry
            ey = tk.Entry(row, width=6, font=("Consolas", 9),
                          bg=_ENTRY_BG, fg="#FFFFFF", insertbackground="white")
            ey.insert(0, f"{self._cim_vars[py['key']].get():.0f}")
            ey.pack(side=tk.LEFT, padx=2)
            self._wire_cim_slider(py, self._cim_vars[py["key"]], ey)

        # CIM Velocity Spline Graph
        self._cim_ax_x   = None
        self._cim_ax_y   = None
        self._cim_canvas = None
        self._build_cim_graph(parent)

        # ── Parameters ────────────────────────────────────────────────────────
        pp = tk.LabelFrame(parent, text="Parameters", padx=8, pady=4,
                           bg=_BG2, fg=_FG, font=("Consolas", 9))
        pp.pack(fill=tk.X, **pad)
        for key in ("sigmaPct", "tEndMs", "xDelay", "yDelay"):
            p = next(x for x in _CIM_PARAMS if x["key"] == key)
            self._build_slider_row(pp, p, self._cim_vars[key], width=220)

        # ── Rapid Fire ────────────────────────────────────────────────────────
        rf = tk.LabelFrame(parent, text="Rapid Fire", padx=8, pady=4,
                           bg=_BG2, fg=_FG, font=("Consolas", 9))
        rf.pack(fill=tk.X, **pad)
        for key in ("rfHz", "rfSpread", "rfDutyPct"):
            p = next(x for x in _CIM_PARAMS if x["key"] == key)
            self._build_slider_row(rf, p, self._cim_vars[key], width=220)

        # ── Aktions-Buttons CIM ───────────────────────────────────────────────
        af = tk.Frame(parent, bg=_BG)
        af.pack(fill=tk.X, padx=8, pady=6)
        tk.Button(af, text="Read CIM",  width=12, command=self._read_cim,
                  bg="#334455", fg="#FFFFFF").pack(side=tk.LEFT, padx=4)
        tk.Button(af, text="Write CIM", width=12, command=self._write_cim,
                  bg="#335544", fg="#FFFFFF").pack(side=tk.LEFT, padx=4)
        tk.Button(af, text="Defaults",  width=10, command=self._load_cim_defaults,
                  bg="#443322", fg="#FFFFFF").pack(side=tk.LEFT, padx=4)
        tk.Button(af, text="Save local", width=12, command=self._save_settings,
                  bg="#222222", fg="#AAAAAA").pack(side=tk.RIGHT, padx=4)

    # ── Slider-Hilfsfunktion ──────────────────────────────────────────────────
    def _build_slider_row(self, parent, pdef: dict, var: tk.DoubleVar, width: int = 240):
        row = tk.Frame(parent, bg=parent.cget("bg"))
        row.pack(fill=tk.X, pady=2)
        unit_str = f" [{pdef['unit']}]" if pdef["unit"] else ""
        tk.Label(row, text=f"{pdef['label']}{unit_str}",
                 width=16, anchor="w", bg=parent.cget("bg"), fg=_DIM,
                 font=("Consolas", 9)).pack(side=tk.LEFT)
        tk.Scale(
            row, variable=var,
            from_=pdef["min"], to=pdef["max"], resolution=pdef["step"],
            orient=tk.HORIZONTAL, length=width, showvalue=False,
            bg=parent.cget("bg"), fg=_DIM, troughcolor=_TROUGH, highlightthickness=0,
        ).pack(side=tk.LEFT, padx=4)
        ent = tk.Entry(row, width=7, font=("Consolas", 10),
                       bg=_ENTRY_BG, fg="#FFFFFF", insertbackground="white")
        ent.insert(0, f"{var.get():{pdef['fmt']}}")
        ent.pack(side=tk.LEFT, padx=2)
        ent.bind("<Return>",   lambda e, pd=pdef, v=var, en=ent: self._on_cim_entry(pd, v, en))
        ent.bind("<FocusOut>", lambda e, pd=pdef, v=var, en=ent: self._on_cim_entry(pd, v, en))
        def _sync(val, en=ent, pd=pdef):
            new = f"{float(val):{pd['fmt']}}"
            if en.get() != new:
                en.delete(0, tk.END)
                en.insert(0, new)
        var.trace_add("write", lambda *_, v=var, cb=_sync: cb(v.get()))

    def _wire_cim_slider(self, pdef: dict, var: tk.DoubleVar, entry: tk.Entry):
        """Bidirektionale Bindung Slider ↔ Entry für CIM-Spline-Slider."""
        entry.bind("<Return>",   lambda e, pd=pdef, v=var, en=entry: self._on_cim_entry(pd, v, en))
        entry.bind("<FocusOut>", lambda e, pd=pdef, v=var, en=entry: self._on_cim_entry(pd, v, en))
        def _sync(val, en=entry, pd=pdef):
            new = f"{float(val):{pd['fmt']}}"
            if en.get() != new:
                en.delete(0, tk.END)
                en.insert(0, new)
        var.trace_add("write", lambda *_, v=var, cb=_sync: cb(v.get()))

    # ── Event-Handler ─────────────────────────────────────────────────────────
    def _on_tab_change(self, _event=None):
        if self._tab_init:
            return
        if not self._connected:
            return
        idx = self._active_tab()
        mode = _MODE_CIM if idx == 1 else _MODE_AIM
        self._set_mode(mode)

    def _on_cim_entry(self, pdef: dict, var: tk.DoubleVar, entry: tk.Entry):
        try:
            v = float(entry.get())
            v = max(pdef["min"], min(pdef["max"], v))
            var.set(v)
        except ValueError:
            entry.delete(0, tk.END)
            entry.insert(0, f"{var.get():{pdef['fmt']}}")

    def _on_map_entry(self, idx: int):
        raw = self._map_vars[idx].get().strip()
        try:
            code = int(raw, 0) & 0xFF
            self._map_vars[idx].set(f"0x{code:02X}")
            self._map_labels[idx].config(text=_key_name(code))
        except ValueError:
            pass

    # ── AIM Defaults ──────────────────────────────────────────────────────────
    def _load_aim_defaults(self):
        for p in _AIM_PARAMS:
            self._aim_vars[p["key"]].set(_AIM_DEFAULTS.get(p["key"], p["min"]))
        self._stick_var.set(1)
        for i, v in enumerate(_AIM_DEFAULTS["map"]):
            self._map_vars[i].set(v)
            try:
                self._map_labels[i].config(text=_key_name(int(v, 0)))
            except ValueError:
                pass

    # ── CIM Defaults ──────────────────────────────────────────────────────────
    def _load_cim_defaults(self):
        for p in _CIM_PARAMS:
            self._cim_vars[p["key"]].set(_CIM_DEFAULTS.get(p["key"], 0.0))

    # ── AIM Graph ─────────────────────────────────────────────────────────────
    def _build_aim_graph(self, parent: tk.Frame):
        gf = tk.LabelFrame(parent, text="Response Curve", padx=4, pady=4,
                           bg=_BG2, fg=_FG, font=("Consolas", 9))
        gf.pack(fill=tk.X, padx=8, pady=(0, 2))

        if not _HAS_MPL:
            tk.Label(gf, text="[matplotlib + numpy required]",
                     bg=_BG2, fg="#666666", font=("Consolas", 8)).pack(pady=6)
            return

        fig = Figure(figsize=(5.6, 1.6), dpi=88, facecolor=_BG2)
        fig.subplots_adjust(left=0.09, right=0.97, top=0.82, bottom=0.28)
        self._aim_ax = fig.add_subplot(111)
        self._aim_canvas = FigureCanvasTkAgg(fig, master=gf)
        self._aim_canvas.get_tk_widget().pack(fill=tk.X)

        for key in ("ema_alpha", "noise_gate", "sensitivity", "max_deflect", "curve_exp"):
            self._aim_vars[key].trace_add("write", self._schedule_aim_redraw)

        self._aim_redraw_job = None
        self._draw_aim_curve()

    def _schedule_aim_redraw(self, *_):
        if self._aim_redraw_job is not None:
            self.root.after_cancel(self._aim_redraw_job)
        self._aim_redraw_job = self.root.after(200, self._draw_aim_curve)

    def _draw_aim_curve(self):
        self._aim_redraw_job = None
        if not _HAS_MPL or not hasattr(self, "_aim_ax") or self._aim_ax is None:
            return
        sens    = max(float(self._aim_vars["sensitivity"].get()), 0.01)
        defl    = max(float(self._aim_vars["max_deflect"].get()), 0.01)
        exp_    = max(float(self._aim_vars["curve_exp"].get()), 0.05)
        ng_frac = float(self._aim_vars["noise_gate"].get()) / 20.0  # noise_gate max=20 px/s

        x = np.linspace(0.0, 1.0, 400)
        # Dead zone
        active = np.maximum(x - ng_frac, 0.0)
        norm   = active / max(1.0 - ng_frac, 0.001)
        y = np.clip(sens * np.power(np.clip(norm, 0.0, 1.0), exp_), 0.0, defl)

        ax = self._aim_ax
        ax.clear()
        ax.set_facecolor("#222222")
        ax.plot(x, y, color="#00CCFF", linewidth=1.5)
        ax.axhline(defl, color="#FF6600", linewidth=0.8, linestyle="--", alpha=0.7)
        if ng_frac > 0:
            ax.axvline(ng_frac, color="#888888", linewidth=0.7, linestyle=":", alpha=0.7)
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(0.0, max(defl * 1.2, 0.1))
        ax.set_title(f"AIM curve  (exp={exp_:.2f}  sens={sens:.2f}  max={defl:.2f})",
                     fontsize=6.5, color="#CCCCCC", pad=2)
        ax.set_xlabel("input (normalized)", fontsize=6, color="#888888")
        ax.set_ylabel("output",             fontsize=6, color="#888888")
        ax.tick_params(colors="#888888", labelsize=6)
        ax.grid(True, color="#333333", linewidth=0.4, linestyle=":")
        for sp in ax.spines.values():
            sp.set_color("#444444")
        self._aim_canvas.draw()

    # ── CIM Graph ─────────────────────────────────────────────────────────────
    @staticmethod
    def _hermite_spline_vec(v7, t_arr, t_end_ms, delay_ms=0.0):
        """Catmull-Rom Hermite-Spline über 7 gleichverteilte Stützstellen (numpy)."""
        v = np.asarray(v7, dtype=float)
        result = np.zeros_like(t_arr, dtype=float)
        active_ms = t_end_ms - delay_ms
        if active_ms <= 0:
            return result
        mask = (t_arr >= delay_ms) & (t_arr < t_end_ms)
        if not np.any(mask):
            return result
        tn = np.clip((t_arr[mask] - delay_ms) / active_ms, 0.0, 1.0)
        sf = tn * 6.0
        s  = np.clip(sf.astype(int), 0, 5)
        u  = sf - s
        p0 = v[s]
        p1 = v[np.clip(s + 1, 0, 6)]
        m0 = np.where(s == 0,
                      p1 - p0,
                      0.5 * (v[np.clip(s + 1, 0, 6)] - v[np.clip(s - 1, 0, 6)]))
        m1 = np.where(s >= 5,
                      p1 - p0,
                      0.5 * (v[np.clip(s + 2, 0, 6)] - v[s]))
        u2 = u * u; u3 = u2 * u
        result[mask] = ((2*u3 - 3*u2 + 1)*p0 + (u3 - 2*u2 + u)*m0
                      + (-2*u3 + 3*u2)*p1   + (u3 - u2)*m1)
        return result

    def _build_cim_graph(self, parent: tk.Frame):
        gf = tk.LabelFrame(parent, text="Velocity Splines", padx=4, pady=4,
                           bg=_BG2, fg=_FG, font=("Consolas", 9))
        gf.pack(fill=tk.X, padx=8, pady=(0, 2))

        if not _HAS_MPL:
            tk.Label(gf, text="[matplotlib + numpy required]",
                     bg=_BG2, fg="#666666", font=("Consolas", 8)).pack(pady=6)
            return

        fig = Figure(figsize=(6.4, 1.7), dpi=88, facecolor=_BG2)
        fig.subplots_adjust(left=0.08, right=0.98, top=0.82, bottom=0.26, wspace=0.38)
        self._cim_ax_x = fig.add_subplot(1, 2, 1)
        self._cim_ax_y = fig.add_subplot(1, 2, 2)
        self._cim_canvas = FigureCanvasTkAgg(fig, master=gf)
        self._cim_canvas.get_tk_widget().pack(fill=tk.X)

        watch_keys = [f"vX{i}" for i in range(7)] + [f"vY{i}" for i in range(7)] + \
                     ["tEndMs", "xDelay", "yDelay"]
        for key in watch_keys:
            self._cim_vars[key].trace_add("write", self._schedule_cim_redraw)

        self._cim_redraw_job = None
        self._draw_cim_spline()

    def _schedule_cim_redraw(self, *_):
        if self._cim_redraw_job is not None:
            self.root.after_cancel(self._cim_redraw_job)
        self._cim_redraw_job = self.root.after(200, self._draw_cim_spline)

    def _draw_cim_spline(self):
        self._cim_redraw_job = None
        if not _HAS_MPL or not hasattr(self, "_cim_ax_x") or self._cim_ax_x is None:
            return
        vx7     = [float(self._cim_vars[f"vX{i}"].get()) for i in range(7)]
        vy7     = [float(self._cim_vars[f"vY{i}"].get()) for i in range(7)]
        t_end   = max(float(self._cim_vars["tEndMs"].get()), 1.0)
        x_delay = float(self._cim_vars["xDelay"].get())
        y_delay = float(self._cim_vars["yDelay"].get())

        X_AXIS = 5000.0
        t = np.linspace(0.0, X_AXIS, 500)

        for ax, v7, delay, color, title in (
            (self._cim_ax_x, vx7, x_delay, "#00AAFF", "X-Speed"),
            (self._cim_ax_y, vy7, y_delay, "#FF7722", "Y-Speed"),
        ):
            eff   = self._hermite_spline_vec(v7, t, t_end, delay)
            half  = max(max(abs(v) for v in v7) * 1.3, 10.0)
            knots = np.linspace(delay, t_end, 7)

            ax.clear()
            ax.set_facecolor("#222222")
            ax.plot(t, eff, color=color, linewidth=1.5)
            ax.axhline(0.0, color="#555555", linewidth=0.6, linestyle="--")
            ax.scatter(knots, v7, color=color, s=28, zorder=5,
                       edgecolors="white", linewidths=0.5)
            ax.set_xlim(0.0, X_AXIS)
            ax.set_ylim(-half, half)
            ax.set_title(title, fontsize=7, color="#CCCCCC", pad=2)
            ax.set_xlabel("t [ms]", fontsize=6, color="#888888")
            ax.set_ylabel("px/s",   fontsize=6, color="#888888")
            ax.tick_params(colors="#888888", labelsize=6)
            ax.grid(True, color="#333333", linewidth=0.4, linestyle=":")
            for sp in ax.spines.values():
                sp.set_color("#444444")

        self._cim_canvas.draw()

    # ── HID-Verbindung ────────────────────────────────────────────────────────
    def _toggle_connection(self):
        if self._connected:
            self._disconnect()
        else:
            self._connect()

    def _connect(self):
        if not _HAS_HID:
            self._log("FEHLER: hid-Paket fehlt (pip install hid)\n", "#FFAAAA")
            return
        devs = [d for d in _hid.enumerate(_HID_VID, _HID_PID)
                if d.get("usage_page") == _HID_UP]
        if not devs:
            self._set_status("Nicht gefunden", "#FFAAAA")
            self._log(f"Gerät VID={_HID_VID:#06x} PID={_HID_PID:#06x} UP={_HID_UP:#06x} nicht gefunden.\n",
                      "#FFAAAA")
            return
        try:
            self._hid_dev = _hid.device()
            self._hid_dev.open_path(devs[0]["path"])
            self._hid_dev.set_nonblocking(0)
            self._connected = True
            self._conn_btn.config(text="Disconnect")
            self._set_status("Connected (HID)", "#AAFFAA")
            self._log(f"Verbunden: {devs[0].get('manufacturer_string', '')} | "
                      f"{devs[0].get('product_string', '')}\n")
            # Aktuellen Mode lesen und richtigen Tab auswählen
            self._tab_init = True
            try:
                mode = self._get_mode()
                if mode == _MODE_CIM:
                    self._nb.select(1)
                    self._read_cim()
                else:
                    self._nb.select(0)
                    self._read_aim()
            finally:
                self._tab_init = False
        except Exception as e:
            self._set_status("Fehler", "#FFAAAA")
            self._log(f"Verbindungsfehler: {e}\n", "#FFAAAA")
            self._hid_dev = None
            self._connected = False

    def _disconnect(self):
        if self._hid_dev:
            try:
                self._hid_dev.close()
            except Exception:
                pass
            self._hid_dev = None
        self._connected = False
        self._conn_btn.config(text="Connect")
        self._set_status("Disconnected", "#DDDDDD")
        self._log("Getrennt.\n")

    # ── Mode Get / Set ────────────────────────────────────────────────────────
    def _get_mode(self) -> int:
        """Fragt Firmware nach gActiveMode. Gibt Mode-Byte zurück (0x02=AIM, 0x03=CIM)."""
        if not self._hid_dev:
            return _MODE_AIM
        try:
            req = bytes([_HID_RPID, _CMD_GET_MODE]) + b'\x00' * 62
            self._hid_dev.send_feature_report(req[:64])
            time.sleep(0.05)
            resp = bytes(self._hid_dev.get_feature_report(_HID_RPID, 65) or b'')
            if len(resp) >= 3 and resp[1] == _CMD_GET_MODE:
                mode = resp[2]
                self._log(f"Mode: {'CIM' if mode == _MODE_CIM else 'AIM'} (0x{mode:02X})\n")
                return mode
        except Exception as e:
            self._log(f"Get-Mode Fehler: {e}\n", "#FFAAAA")
        return _MODE_AIM

    def _set_mode(self, mode: int):
        """Setzt gActiveMode in der Firmware (kein Reboot)."""
        if not self._hid_dev:
            return
        try:
            data = bytes([_HID_RPID, _CMD_SET_MODE, mode]) + b'\x00' * 61
            self._hid_dev.send_feature_report(data[:64])
            label = "CIM" if mode == _MODE_CIM else "AIM"
            self._log(f"Mode → {label}\n")
        except Exception as e:
            self._log(f"Set-Mode Fehler: {e}\n", "#FFAAAA")

    # ── AIM Read / Write ──────────────────────────────────────────────────────
    def _pack_aim(self) -> bytes:
        ema   = float(self._aim_vars["ema_alpha"].get())
        ng    = float(self._aim_vars["noise_gate"].get())
        sens  = float(self._aim_vars["sensitivity"].get())
        defl  = float(self._aim_vars["max_deflect"].get())
        exp_  = float(self._aim_vars["curve_exp"].get())
        stick = int(self._stick_var.get())
        map_b = bytearray(16)
        for i in range(16):
            try:
                map_b[i] = int(self._map_vars[i].get(), 0) & 0xFF
            except ValueError:
                map_b[i] = 0
        return _AIM_STRUCT.pack(0, 0, ema, ng, sens, defl, exp_,
                                bytes(map_b), stick, 0, 0, 0)

    def _unpack_aim(self, payload: bytes):
        (_, _, ema, ng, sens, defl, exp_,
         map_b, stick, *_) = _AIM_STRUCT.unpack(payload[:_AIM_STRUCT.size])
        self._aim_vars["ema_alpha"].set(round(ema, 4))
        self._aim_vars["noise_gate"].set(round(ng, 4))
        self._aim_vars["sensitivity"].set(round(sens, 4))
        self._aim_vars["max_deflect"].set(round(defl, 4))
        self._aim_vars["curve_exp"].set(round(exp_, 4))
        self._stick_var.set(stick)
        for i, b in enumerate(map_b[:16]):
            self._map_vars[i].set(f"0x{b:02X}")
            self._map_labels[i].config(text=_key_name(b))

    def _read_aim(self):
        if not self._hid_dev:
            self._log("Nicht verbunden.\n", "#FFAAAA")
            return
        try:
            req = bytes([_HID_RPID, _CMD_READ_AIM]) + b'\x00' * 62
            self._hid_dev.send_feature_report(req[:64])
            time.sleep(0.05)
            resp = bytes(self._hid_dev.get_feature_report(_HID_RPID, 65) or b'')
            if len(resp) < 2 + _AIM_STRUCT.size or resp[1] != _CMD_READ_AIM:
                self._log(f"Read AIM: unerwartete Antwort (len={len(resp)}"
                          f" cmd={resp[1] if len(resp)>1 else '?'})\n", "#FFAAAA")
                return
            self._unpack_aim(resp[2:])
            self._log("Read AIM OK\n")
        except Exception as e:
            self._log(f"Read AIM Fehler: {e}\n", "#FFAAAA")

    def _write_aim(self):
        if not self._hid_dev:
            self._log("Nicht verbunden.\n", "#FFAAAA")
            return
        try:
            payload = self._pack_aim()
            data = bytes([_HID_RPID, _CMD_WRITE_AIM]) + payload
            data = (data + b'\x00' * 64)[:64]
            self._hid_dev.send_feature_report(data)
            self._log("Write AIM OK\n")
            self._save_settings()
        except Exception as e:
            self._log(f"Write AIM Fehler: {e}\n", "#FFAAAA")

    # ── CIM Read / Write ──────────────────────────────────────────────────────
    def _read_cim(self):
        if not self._hid_dev:
            self._log("Nicht verbunden.\n", "#FFAAAA")
            return
        try:
            req = bytes([_HID_RPID, _CMD_READ_CIM]) + b'\x00' * 62
            self._hid_dev.send_feature_report(req[:64])
            time.sleep(0.05)
            resp = bytes(self._hid_dev.get_feature_report(_HID_RPID, 65) or b'')
            if len(resp) < 2 + _CIM_STRUCT.size or resp[1] != _CMD_READ_CIM:
                self._log(f"Read CIM: unerwartete Antwort (len={len(resp)}"
                          f" cmd={resp[1] if len(resp)>1 else '?'})\n", "#FFAAAA")
                return
            payload = resp[2:2 + _CIM_STRUCT.size]
            (sigmaPct, rfSpread, tEndMs,
             vx0, vx1, vx2, vx3, vx4, vx5, vx6,
             vy0, vy1, vy2, vy3, vy4, vy5, vy6,
             rfHz, xDelay, yDelay,
             rfDutyPct, axis_lx, axis_ly, fire_btn, res0, res1,
             cimSens) = _CIM_STRUCT.unpack(payload)
            # Cache unsichtbare Felder für Round-Trip
            self._hid_extra_cim = {
                'axis_lx': axis_lx, 'axis_ly': axis_ly,
                'fire_btn': fire_btn, '_res0': res0, '_res1': res1,
                'cimSens': cimSens,
            }
            # GUI aktualisieren
            for i, v in enumerate([vx0, vx1, vx2, vx3, vx4, vx5, vx6]):
                self._cim_vars[f"vX{i}"].set(float(v))
            for i, v in enumerate([vy0, vy1, vy2, vy3, vy4, vy5, vy6]):
                self._cim_vars[f"vY{i}"].set(float(v))
            self._cim_vars["xDelay"].set(float(xDelay))
            self._cim_vars["yDelay"].set(float(yDelay))
            self._cim_vars["sigmaPct"].set(float(sigmaPct))
            self._cim_vars["rfHz"].set(float(rfHz))
            self._cim_vars["rfSpread"].set(float(rfSpread))
            self._cim_vars["rfDutyPct"].set(float(rfDutyPct))
            self._cim_vars["tEndMs"].set(float(tEndMs))
            self._log("Read CIM OK\n")
        except Exception as e:
            self._log(f"Read CIM Fehler: {e}\n", "#FFAAAA")

    def _write_cim(self):
        if not self._hid_dev:
            self._log("Nicht verbunden.\n", "#FFAAAA")
            return
        try:
            ex = self._hid_extra_cim
            vx = tuple(int(self._cim_vars[f"vX{i}"].get()) for i in range(7))
            vy = tuple(int(self._cim_vars[f"vY{i}"].get()) for i in range(7))
            payload = _CIM_STRUCT.pack(
                float(self._cim_vars["sigmaPct"].get()),
                float(self._cim_vars["rfSpread"].get()),
                int(self._cim_vars["tEndMs"].get()),
                *vx,
                *vy,
                float(self._cim_vars["rfHz"].get()),
                int(self._cim_vars["xDelay"].get()),
                int(self._cim_vars["yDelay"].get()),
                int(self._cim_vars["rfDutyPct"].get()),
                int(ex.get('axis_lx', 0)),
                int(ex.get('axis_ly', 1)),
                int(ex.get('fire_btn', 0)),
                int(ex.get('_res0', 0)),
                int(ex.get('_res1', 0)),
                float(ex.get('cimSens', 1.0)),
            )
            data = bytes([_HID_RPID, _CMD_WRITE_CIM]) + payload
            data = (data + b'\x00' * 64)[:64]
            self._hid_dev.send_feature_report(data)
            self._log("Write CIM OK\n")
            self._save_settings()
        except Exception as e:
            self._log(f"Write CIM Fehler: {e}\n", "#FFAAAA")

    # ── Hilfsmethoden ─────────────────────────────────────────────────────────
    def _set_status(self, text: str, bg: str = "#DDDDDD"):
        self._status_var.set(text)
        self._status_lbl.config(bg=bg)

    def _log(self, msg: str, fg: str = "#AAFFAA"):
        self._log_box.config(state=tk.NORMAL)
        self._log_box.insert(tk.END, msg)
        self._log_box.see(tk.END)
        self._log_box.config(state=tk.DISABLED)


def main():
    root = tk.Tk()
    AimControlApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
